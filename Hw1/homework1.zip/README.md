Homework 1

Shirin Kuppusamy

Colin Snow

Maia Materman
